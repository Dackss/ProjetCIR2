<h2>Recherche</h2>
<form id="rechercheForm">
  <select class="form-select mb-3" name="onduleur">
    <option>Marque onduleur</option>
  </select>
  <select class="form-select mb-3" name="panneau">
    <option>Marque panneau</option>
  </select>
  <select class="form-select mb-3" name="departement">
    <option>Département</option>
  </select>
  <button type="submit" class="btn btn-primary">Rechercher</button>
</form>
<div id="resultats"></div>
