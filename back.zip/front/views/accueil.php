<h2 class="mb-4">Bienvenue !</h2>
<p class="lead">Cette application permet de suivre les installations photovoltaïques chez les particuliers.</p>

<div class="row text-center">
  <div class="col-md-4"><div class="card p-3"><h5>Installations</h5><p>18</p></div></div>
  <div class="col-md-4"><div class="card p-3"><h5>Installateurs</h5><p>16</p></div></div>
  <div class="col-md-4"><div class="card p-3"><h5>Marques Onduleurs</h5><p>22</p></div></div>
</div>

<div class="text-center mt-5">
  <a href="index.php?page=recherche" class="btn btn-primary m-2">Recherche</a>
  <a href="index.php?page=carte" class="btn btn-success m-2">Carte</a>
</div>
