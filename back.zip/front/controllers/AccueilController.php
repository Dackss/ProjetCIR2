<?php
require_once 'views/layout/header.php';
require_once 'views/accueil.php';
require_once 'views/layout/footer.php';
