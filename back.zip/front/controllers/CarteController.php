<?php
require_once 'views/layout/header.php';
require_once 'views/carte.php';
require_once 'views/layout/footer.php';
