CREATE ROLE "projetCIR2" WITH LOGIN PASSWORD 'isen';

CREATE DATABASE "projetCIR2"
    WITH OWNER = "projetCIR2"
    ENCODING = 'UTF8'
    LC_COLLATE = 'C.utf8'
    LC_CTYPE = 'C.utf8'
    TEMPLATE = template0;

GRANT ALL PRIVILEGES ON DATABASE "projetCIR2" TO "projetCIR2";
