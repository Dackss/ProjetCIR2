<header class="header">
    <div class="d-flex justify-content-between align-items-center w-100 px-4">
        <div class="d-flex align-items-center">
            <img src="images/logo1.jpg" alt="logo" class="header-logo me-3">
            <h1 class="h4 mb-0">Espace Administrateur</h1>
        </div>
        <nav>
            <a href="index.php?page=back-office/AdminAccueil">Accueil</a>
            <a href="index.php?page=AdminInstallations">Installations</a>
            <a href="index.php?page=AdminCarte">Carte</a>
            <a href="index.php?page=AdminDeconnexion">Déconnexion</a>
        </nav>
    </div>
</header>
