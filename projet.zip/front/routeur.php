<?php
$page = $_GET['page'] ?? 'accueil';

switch ($page) {
    case 'accueil':
        require_once __DIR__ . '/../back/controllers/AccueilController.php';
        break;

    case 'recherche':
        require_once __DIR__ . '/../back/controllers/RechercheController.php';
        break;

    case 'detail':
        require_once __DIR__ . '/../back/controllers/DetailController.php';
        break;

    case 'carte':
        require_once __DIR__ . '/views/client/carte.php';
        break;

    case 'installations_api': // pour que le JS puisse appeler l’API
        require_once __DIR__ . '/../back/api/installations.php';
        break;

    default:
        http_response_code(404);
        echo "<h1>Page introuvable</h1>";
        break;
}
