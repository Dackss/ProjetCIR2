<?php
require_once 'views/layout/header.php';
require_once 'views/recherche.php';
require_once 'views/layout/footer.php';
