<?php
require_once __DIR__ . '/../core/RequireAdmin.php';
require_once __DIR__ . '/../../front/views/layout/AdminHeader.php';
require_once __DIR__ . '/../../front/views/back-office/AdminCarte.php';
require_once __DIR__ . '/../../front/views/layout/AdminFooter.php';