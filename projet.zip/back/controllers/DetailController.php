<?php
require_once __DIR__ . '/../../front/views/layout/header.php';
require_once __DIR__ . '/../../front/views/client/detail.php';
require_once __DIR__ . '/../../front/views/layout/footer.php';