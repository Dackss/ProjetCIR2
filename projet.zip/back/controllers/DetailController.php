<?php
require_once 'views/layout/header.php';
require_once 'views/detail.php';
require_once 'views/layout/footer.php';
