<?php

const DB_HOST = 'localhost';
const DB_NAME = 'projetCIR2';
const DB_USER = 'projetCIR2';
const DB_PASS = 'isen';
